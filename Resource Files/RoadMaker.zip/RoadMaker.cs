﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshCollider))]
public class RoadMaker : MonoBehaviour {

    public float radius = 30f;
    public float segments = 300f;

    public GameObject car;

    public float lineWidth = 0.3f;
    public float roadWidth = 8f;
    public float edgeWidth = 1f;
    public float edgeHeight = 1f;

    public float wavyness = 5f;
    public float waveScale = .1f;

    public Vector2 waveOffset;
    public Vector2 waveStep = new Vector2(0.01f, 0.01f);

    private bool stripeCheck = true;

	void Start () {
        MeshFilter meshFilter = this.GetComponent<MeshFilter>();
        MeshCollider meshCollider = this.GetComponent<MeshCollider>();
        MeshBuilder mb = new MeshBuilder(6);

        float segmentDegrees = 360f / segments;

        List<Vector3> points = new List<Vector3>();

        for (float degrees = 0; degrees < 360f; degrees += segmentDegrees)
        {
            Vector3 point = Quaternion.AngleAxis(degrees, Vector3.up) * Vector3.forward * radius;
            points.Add(point);
        }

        Vector2 wave = this.waveOffset;

        for (int i = 0; i < points.Count; i++)
        {
            wave += waveStep;

            Vector3 p0 = points[i];
            Vector3 centerDir = p0.normalized;

            float sample = Mathf.PerlinNoise(wave.x * waveScale, wave.y * waveScale);
            sample *= wavyness;

            float control = Mathf.PingPong(i, points.Count / 2f) / (points.Count / 2f);

            points[i] += centerDir * sample * control;

        }



        for (int i = 1; i < points.Count + 1; i++)
        {
            Vector3 pPrev = points[i - 1];
            Vector3 p0 = points[i % points.Count];
            Vector3 p1 = points[(i + 1) % points.Count];

            ExtrudeRoad(mb, pPrev, p0, p1);
        }

        car.transform.position = points[0];
        car.transform.LookAt(points[1]);

        meshFilter.mesh = mb.CreateMesh();
        meshCollider.sharedMesh = meshFilter.mesh;
	}

    private void ExtrudeRoad (MeshBuilder mb, Vector3 pPrev, Vector3 p0, Vector3 p1)
    {
        //Roadline
        Vector3 offset = Vector3.zero;
        Vector3 target = Vector3.forward * lineWidth;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, 0);

        //Road
        offset += target;
        target = Vector3.forward * roadWidth;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, 1);

        int stripeSubmesh = 2;

        if (stripeCheck)
            stripeSubmesh = 3;

        stripeCheck = !stripeCheck;


        //edge
        offset += target;
        target = Vector3.up * edgeHeight;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, stripeSubmesh);

        //edge top
        offset += target;
        target = Vector3.forward * edgeWidth;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, stripeSubmesh);

        //edge
        offset += target;
        target = -Vector3.up * edgeHeight;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, stripeSubmesh);

    }

    private void MakeRoadQuad (MeshBuilder mb, Vector3 pPrev, Vector3 p0, Vector3 p1, Vector3 offset, Vector3 targetOffset, int submesh)
    {
        Vector3 forward = (p1 - p0).normalized;
        Vector3 forwardPrev = (p0 - pPrev).normalized;
        //Build Outer
        Quaternion perp = Quaternion.LookRotation(
            Vector3.Cross(forward, Vector3.up)
            );
        Quaternion perpPrev = Quaternion.LookRotation(
            Vector3.Cross(forwardPrev, Vector3.up)
            );

        Vector3 tl = p0 + (perpPrev * offset);
        Vector3 tr = p0 + (perpPrev * (offset + targetOffset));

        Vector3 bl = p1 + (perp * offset);
        Vector3 br = p1 + (perp * (offset + targetOffset));

        mb.BuildTriangle(tl, tr, bl, submesh);
        mb.BuildTriangle(tr, br, bl, submesh);

        //Build Inner
        perp = Quaternion.LookRotation(
            Vector3.Cross(-forward, Vector3.up)
            );
        perpPrev = Quaternion.LookRotation(
            Vector3.Cross(-forwardPrev, Vector3.up)
            );

        tl = p0 + (perpPrev * offset);
        tr = p0 + (perpPrev * (offset + targetOffset));

        bl = p1 + (perp * offset);
        br = p1 + (perp * (offset + targetOffset));

        mb.BuildTriangle(bl, br, tl, submesh);
        mb.BuildTriangle(br, tr, tl, submesh);
    }

}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshCollider))]
public class RoadMakerV2 : MonoBehaviour {

    public float radius = 30f;
    public float segments = 300f;

    public GameObject car;

    public float lineWidth = 0.3f;
    public float roadWidth = 8f;
    public float edgeWidth = 1f;
    public float edgeHeight = 1f;

    public float wavyness = 5f;
    public float waveScale = .1f;

    public Vector2 waveOffset;
    public Vector2 waveStep = new Vector2(0.01f, 0.01f);

    public float stepLength = 1f;
    public float stepMaxAngle = 1f;
    public int shapeSides = 3;

    private bool stripeCheck = true;

	void Start () {
        MeshFilter meshFilter = this.GetComponent<MeshFilter>();
        MeshCollider meshCollider = this.GetComponent<MeshCollider>();
        MeshBuilder mb = new MeshBuilder(6);


        //List<Vector3> points = MakeCircle();
        List<Vector3> points = AdvancedTrackShape(shapeSides);
        
        for (int i = 1; i < points.Count + 1; i++)
        {
            Vector3 pPrev = points[i - 1];
            Vector3 p0 = points[i % points.Count];
            Vector3 p1 = points[(i + 1) % points.Count];

            ExtrudeRoad(mb, pPrev, p0, p1);
        }

        car.transform.position = points[0];
        car.transform.LookAt(points[1]);

        meshFilter.mesh = mb.CreateMesh();
        meshCollider.sharedMesh = meshFilter.mesh;
	}

    private List<Vector3> ApplyWave(List<Vector3> points)
    {
        Vector2 wave = this.waveOffset;

        for (int i = 0; i < points.Count; i++)
        {
            wave += waveStep;

            Vector3 p0 = points[i];
            Vector3 centerDir = p0.normalized;

            float sample = Mathf.PerlinNoise(wave.x * waveScale, wave.y * waveScale);
            sample *= wavyness;

            float control = Mathf.PingPong(i, points.Count / 2f) / (points.Count / 2f);

            points[i] += centerDir * sample * control;

        }

        return points;
    }

    private List<Vector3> MakeCircle ()
    {
        float segmentDegrees = 360f / segments;

        List<Vector3> points = new List<Vector3>();

        for (float degrees = 0; degrees < 360f; degrees += segmentDegrees)
        {
            Vector3 point = Quaternion.AngleAxis(degrees, Vector3.up) * Vector3.forward * radius;
            points.Add(point);
        }

        ApplyWave(points);

        return points;
    }

    private List<Vector3> AdvancedTrackShape(int sides)
    {
        //create a point list of 4 corners
        List<Vector3> points = new List<Vector3>();

        //creates shape corners
        for (int i = 0; i < sides; i++)
        {
            Vector3 point = Quaternion.AngleAxis(90 * i, Vector3.up) * Vector3.forward * radius;
            points.Add(point);
        }
        
        //adds a randm point of variance
        Vector3 randomPoint = Quaternion.AngleAxis((90f * Random.Range(0, 10)) + 45f, Vector3.up) * Vector3.forward * radius * 0.5f;
        points.Insert(Random.Range(0, points.Count), randomPoint);

        //apply the wave here to add variance
        ApplyWave(points);


        //create a traverser to create multiple points along the line, and to widen turns
        
        List<Vector3> dividePoints = new List<Vector3>();

        Vector3 dir = (points[ points.Count - 1 ] - points[points.Count - 2]).normalized;
        Vector3 traversePoint = points[0];
        //get a corner and the target corner, and keep doing that till all sides built
        //do this several tims to smooth out the shape
        for (int j = 0; j < 6; j++)
        {
            dividePoints.Clear();

            for (int i = 0; i < points.Count; i++)
            {
                Vector3 c0 = points[i];
                Vector3 c1 = points[(i + 1) % points.Count];
                float traverseDist = 0;

                while (traverseDist < Vector3.Distance(c0, c1))
                {
                    traverseDist += stepLength;
                    traversePoint += (dir * stepLength);
                    dividePoints.Add(traversePoint);
                    dir = Quaternion.RotateTowards(
                        Quaternion.LookRotation(dir),
                        Quaternion.LookRotation((c1 - traversePoint).normalized),
                        stepMaxAngle) * Vector3.forward;
                }

            }
        }

        return dividePoints;
    }

    private void ExtrudeRoad (MeshBuilder mb, Vector3 pPrev, Vector3 p0, Vector3 p1)
    {
        //Roadline
        Vector3 offset = Vector3.zero;
        Vector3 target = Vector3.forward * lineWidth;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, 0);

        //Road
        offset += target;
        target = Vector3.forward * roadWidth;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, 1);

        int stripeSubmesh = 2;

        if (stripeCheck)
            stripeSubmesh = 3;

        stripeCheck = !stripeCheck;


        //edge
        offset += target;
        target = Vector3.up * edgeHeight;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, stripeSubmesh);

        //edge top
        offset += target;
        target = Vector3.forward * edgeWidth;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, stripeSubmesh);

        //edge
        offset += target;
        target = -Vector3.up * edgeHeight;

        MakeRoadQuad(mb, pPrev, p0, p1, offset, target, stripeSubmesh);

    }

    private void MakeRoadQuad (MeshBuilder mb, Vector3 pPrev, Vector3 p0, Vector3 p1, Vector3 offset, Vector3 targetOffset, int submesh)
    {
        Vector3 forward = (p1 - p0).normalized;
        Vector3 forwardPrev = (p0 - pPrev).normalized;
        //Build Outer
        Quaternion perp = Quaternion.LookRotation(
            Vector3.Cross(forward, Vector3.up)
            );
        Quaternion perpPrev = Quaternion.LookRotation(
            Vector3.Cross(forwardPrev, Vector3.up)
            );

        Vector3 tl = p0 + (perpPrev * offset);
        Vector3 tr = p0 + (perpPrev * (offset + targetOffset));

        Vector3 bl = p1 + (perp * offset);
        Vector3 br = p1 + (perp * (offset + targetOffset));

        mb.BuildTriangle(tl, tr, bl, submesh);
        mb.BuildTriangle(tr, br, bl, submesh);

        //Build Inner
        perp = Quaternion.LookRotation(
            Vector3.Cross(-forward, Vector3.up)
            );
        perpPrev = Quaternion.LookRotation(
            Vector3.Cross(-forwardPrev, Vector3.up)
            );

        tl = p0 + (perpPrev * offset);
        tr = p0 + (perpPrev * (offset + targetOffset));

        bl = p1 + (perp * offset);
        br = p1 + (perp * (offset + targetOffset));

        mb.BuildTriangle(bl, br, tl, submesh);
        mb.BuildTriangle(br, tr, tl, submesh);
    }

}
